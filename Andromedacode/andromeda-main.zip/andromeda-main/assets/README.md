# PHP ve MySQL ile Veritabanı Uygulaması

Mehmet Selçuk Batal Youtube adresinde bulunan PHP ve MySQL ile Veritabanı Uygulaması konulu eğitim videosunun (https://youtu.be/rfKvUQxuzRI) dosyalarını burada bulabilirsiniz.

Uygulamayı yapmak için https://youtu.be/rfKvUQxuzRI adresinde bulunan videoyu takip etmeniz gerekmektedir. Uygulama içerisinde PHP ve MySQL ile veritabanına kayıt ekleme, kayıt silme, kayıt güncelleme ve kayıt listeleme işlemleri yapılmaktadır.

Eğer uygulamayı yaparken sorunlarla karşılaşırsanız, size yardımcı olması amacıyla burada bulunan dosyaları inceleyebilirsiniz.

Faydalı olması dileğiyle...

Mehmet Selçuk Batal
